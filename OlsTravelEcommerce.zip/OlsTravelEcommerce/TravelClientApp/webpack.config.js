const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const nodeExternals = require('webpack-node-externals');
const webpack = require("webpack");
const MiniCssExtractPlugin = require("mini-css-extract-plugin");

// Common assets file types which are for `file-loader`
const reImage = /\.(ico|jpg|jpeg|png|gif|eot|otf|svg|webp|ttf|woff|woff2)$/;
// css files
const reScss = /\.(css|scss|sass|less)$/;

const angReg = /angular(\\|\/)core/;

module.exports = {
    entry: {
        pollyfill:'./angular-pollyfills.ts',
        getaquote: './getaquote/getaquote.ts',
        yourquotation: './yourquotation/yourquotation.ts'
    },
    mode: 'development',
    output: {
        path: path.resolve(__dirname, '../wwwroot/js'),
        filename: '[name].bundle.js'
    },
    resolve: {
        extensions: ['.tsx', '.ts', '.js'],
    },
    module: {
        rules: [
            {
                test: /\.tsx?$/,
                use:[ 'ts-loader','angular2-template-loader'],

                exclude: /node_modules/,
            },
            {
                test: /\.html$/,
                loader: 'html-loader',
            },
            {
                test: /\.css$/i,
                use: [MiniCssExtractPlugin.loader,'css-loader']
            },
            
            // Add other rules as necessary
        ]
    },

    plugins: [
        new MiniCssExtractPlugin(),
        new webpack.ContextReplacementPlugin(angReg,path.resolve(__dirname,"./getaquote").toString(),{}),
        new HtmlWebpackPlugin({
            template: './getaquote/index.html'
        })
    ],
    devServer: {
        static: {
            directory: path.join(__dirname, '../wwwroot/js')
        },

        historyApiFallback: true,
        port: 9803,
        hot: true,

    }
};