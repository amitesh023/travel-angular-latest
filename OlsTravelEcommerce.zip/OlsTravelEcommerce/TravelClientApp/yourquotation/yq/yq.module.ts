import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser'
import {YqComponent} from './yq.component'


@NgModule({
    declarations: [
        YqComponent
    ],
    imports: [
        BrowserModule
    ],
    bootstrap: [YqComponent],
    schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})

export class YqModule { }