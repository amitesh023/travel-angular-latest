import { Component } from "@angular/core";
import { NgIf} from "@angular/common"

@Component({
    selector: 'yq-root',
    template: `<h1>Your Quotation.</h1>`
})
export class YqComponent  {
}