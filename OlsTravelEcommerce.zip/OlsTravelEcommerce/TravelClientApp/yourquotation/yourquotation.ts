import { platformBrowserDynamic } from "@angular/platform-browser-dynamic";
import { YqModule } from "./yq/yq.module";
import 'zone.js'

platformBrowserDynamic().bootstrapModule(YqModule)
.catch(err => console.error(err));